package com.example.app1


    import android.os.Bundle
    import androidx.appcompat.app.AppCompatActivity

    class FourActivity : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_four)
        }
    }

