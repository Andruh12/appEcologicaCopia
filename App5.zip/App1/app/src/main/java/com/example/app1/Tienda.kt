package com.example.app1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.app1.R

class Tienda : AppCompatActivity() {

    // Lista de productos
    private val products = listOf(
        Product("Tenis Azules", 10.00),
        Product("Tenis Beige", 12.00),
        Product("Tenis Blancos", 15.00),
        Product("Tenis Negros", 20.00)
    )

    // Carrito de compras
    private val cart = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tienda)

        // Llamar a updateCart para inicializar el estado del carrito al inicio
        updateCart()

        // Configurar el evento de clic para el botón "Siguiente"
        val nextButton: Button = findViewById(R.id.next_button)
        nextButton.setOnClickListener { onNextClick() }
    }

    // Función para actualizar el carrito
    private fun updateCart() {
        val cartCount = findViewById<TextView>(R.id.cart_count)
        val payButton = findViewById<Button>(R.id.pay_button)

        // Actualizar el contador de productos en el carrito
        cartCount.text = cart.size.toString()

        // Mostrar u ocultar el contador y el botón de pago según el estado del carrito
        if (cart.isEmpty()) {
            cartCount.visibility = View.GONE
            payButton.visibility = View.GONE
        } else {
            cartCount.visibility = View.VISIBLE
            payButton.visibility = View.VISIBLE
        }
    }

    // Función para agregar productos al carrito
    fun onAddToCartClick(view: View) {
        // Obtener el id del botón que fue presionado
        val id = view.id

        // Identificar el producto basado en el id del botón
        val product = when (id) {
            R.id.add_to_cart_1 -> products[0]
            R.id.add_to_cart_2 -> products[1]
            R.id.add_to_cart_3 -> products[2]
            R.id.add_to_cart_4 -> products[3]
            else -> null
        }

        // Si el producto es válido, agregarlo al carrito y actualizar la UI
        product?.let {
            cart.add(it)
            Toast.makeText(this, "${it.name} agregado al carrito", Toast.LENGTH_SHORT).show()
            updateCart()  // Actualiza el carrito en la UI
        }
    }

    // Función para mostrar los productos del carrito cuando se hace clic en el carrito
    fun onShoppingCartClick(view: View) {
        val cartItems = cart.joinToString(", ") { "${it.name} - $${it.price}" }
        if (cart.isEmpty()) {
            Toast.makeText(this, "El carrito está vacío", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Carrito: $cartItems", Toast.LENGTH_LONG).show()
        }
    }

    // Función para proceder al pago (puedes agregar la lógica de pago aquí)
    fun onPayClick(view: View) {
        if (cart.isEmpty()) {
            Toast.makeText(this, "El carrito está vacío", Toast.LENGTH_SHORT).show()
        } else {
            // Aquí puedes agregar la lógica de pago o redirigir al usuario a otra pantalla
            Toast.makeText(this, "Pagando por ${cart.size} productos", Toast.LENGTH_SHORT).show()
        }
    }

    // Función para redirigir a Tienda2
    private fun onNextClick() {
        // Crear un Intent para pasar de Tienda a Tienda2
        val intent = Intent(this, Tienda2::class.java)
        startActivity(intent)
    }

    // Clase para los productos
    data class Product(val name: String, val price: Double)
}
