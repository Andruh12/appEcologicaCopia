package com.example.app1

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class FourActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_four)

        // Referencias a los EditText y el botón
        val editTextTelefono: EditText = findViewById(R.id.editTextTelefono)
        val editTextCorreo: EditText = findViewById(R.id.editTextCorreo)
        val botonRegistrar: MaterialButton = findViewById(R.id.boton_registrar)

        // Configuración del botón de registro
        botonRegistrar.setOnClickListener {
            // Validación del teléfono
            val telefono = editTextTelefono.text.toString()
            if (!esTelefonoValido(telefono)) {
                Toast.makeText(this, "Por favor ingresa un teléfono válido con 10 dígitos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Validación del correo
            val correo = editTextCorreo.text.toString()
            if (!esCorreoValido(correo)) {
                Toast.makeText(this, "Por favor ingresa un correo válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Si todo es válido, puedes proceder con el registro o la siguiente acción
            Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
        }
    }

    // Función que valida el teléfono (solo números y longitud mínima de 10)
    private fun esTelefonoValido(telefono: String): Boolean {
        return telefono.length >= 10 && telefono.all { it.isDigit() }
    }

    // Función que valida el correo (debe contener el '@')
    private fun esCorreoValido(correo: String): Boolean {
        return correo.contains("@")
    }
}
