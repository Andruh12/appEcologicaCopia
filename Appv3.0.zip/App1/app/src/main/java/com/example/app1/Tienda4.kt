import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.app1.R

class Tienda4 : AppCompatActivity() {

    // Lista de productos (cambiando los productos a camisa1, camisa2, camisa3 y camisa4)
    private val products = listOf(
        Product("Pantaloneta AzulOscuro", 10.00),
        Product("Pantaloneta verde", 12.00),
        Product("Pantaloneta Azul", 15.00),
        Product("Gorra AguaMarina", 18.00)
    )

    // Carrito de compras
    private val cart = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tienda)

        // Llama a updateCart para inicializar el estado del carrito al inicio
        updateCart()
    }

    // Función para actualizar el carrito (contador de productos y visibilidad del botón de pago)
    fun updateCart() {
        val cartCount = findViewById<TextView>(R.id.cart_count)
        val payButton = findViewById<Button>(R.id.pay_button)

        // Actualizar el contador de productos en el carrito
        cartCount.text = cart.size.toString()

        // Mostrar u ocultar el contador y el botón de pago según el estado del carrito
        if (cart.isEmpty()) {
            cartCount.visibility = View.GONE
            payButton.visibility = View.GONE
        } else {
            cartCount.visibility = View.VISIBLE
            payButton.visibility = View.VISIBLE
        }
    }

    // Función para agregar productos al carrito
    fun onAddToCartClick(view: View) {
        // Obtener el nombre del producto desde el TextView del producto
        val parent = view.parent as LinearLayout
        val productText = (parent.getChildAt(1) as TextView).text.toString()

        // Buscar el producto correspondiente por nombre
        val product = products.find { it.name == productText }

        // Si el producto es válido, agregarlo al carrito y actualizar la UI
        product?.let {
            cart.add(it)
            Toast.makeText(this, "${it.name} agregado al carrito", Toast.LENGTH_SHORT).show()
            updateCart()  // Actualiza el carrito en la UI
        }
    }

    // Función para mostrar los productos del carrito cuando se hace clic en el carrito
    fun onShoppingCartClick(view: View) {
        val cartItems = cart.joinToString(", ") { "${it.name} - $${it.price}" }
        if (cart.isEmpty()) {
            Toast.makeText(this, "El carrito está vacío", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Carrito: $cartItems", Toast.LENGTH_LONG).show()
        }
    }

    // Clase para los productos (esto puede estar en otro archivo de tu proyecto)
    data class Product(val name: String, val price: Double)
}

